﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// For Scene Switch Behavior

public class SceneChange : MonoBehaviour {

	public void ChangeToScene(string sceneName){
		SceneManager.LoadScene (sceneName);
	}


}
